# Decentralized-Federated-learning-for-IoMT-Anomaly-Detection
Decentralized federated learning trains AI models on distributed IoT devices, enabling privacy-preserving, collaborative anomaly detection in IoT networks without centralized data collection, improving security and scalability.
